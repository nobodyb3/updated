import FadeInSection from '@/components/ui/motion/FadeInSection';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Award, ShieldCheck, Check, Heart } from 'lucide-react';
import { useEffect } from 'react';
import { useLocation } from 'wouter';

interface ProductsProps {
  openContactModal: (product?: string) => void;
}

const Products = ({ openContactModal }: ProductsProps) => {
  const [location] = useLocation();
  
  // Handle URL hash for scrolling to product sections
  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      const element = document.getElementById(hash.substring(1));
      if (element) {
        setTimeout(() => {
          window.scrollTo({
            top: element.offsetTop - 100,
            behavior: 'smooth'
          });
        }, 100);
      }
    }
  }, [location]);

  return (
    <>
      {/* Products Hero Section */}
      <section className="relative py-20 bg-cover bg-center pt-32" style={{backgroundImage: `url('https://images.unsplash.com/photo-1535914254981-b5012eebbd15?auto=format&fit=crop&q=80&w=1470')`}}>
        <div className="absolute inset-0 bg-secondary bg-opacity-80"></div>
        <div className="container mx-auto px-4 relative z-10">
          <FadeInSection>
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-white font-display leading-tight mb-4">
                Our Premium Products
              </h1>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-xl text-white opacity-90">
                Discover our range of high-quality beef, lamb, and poultry products exported worldwide.
              </p>
            </div>
          </FadeInSection>
        </div>
      </section>
      
      {/* Beef Products */}
      <section id="beef" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <FadeInSection className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
              <img 
                src="https://images.unsplash.com/photo-1551028150-64b9f398f678?auto=format&fit=crop&q=80&w=1374" 
                alt="Premium Beef Products" 
                className="rounded-lg shadow-md"
              />
            </FadeInSection>
            
            <FadeInSection delay={0.2} className="md:w-1/2">
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">Premium Beef</h2>
              <div className="w-20 h-1 bg-primary mb-6"></div>
              <p className="text-gray-700 mb-4">
                Our premium beef is sourced from grass-fed cattle raised in open pastures, ensuring exceptional quality, 
                taste, and tenderness. Each cut is carefully selected and processed to meet the highest standards.
              </p>
              <p className="text-gray-700 mb-6">We offer a wide range of beef products including:</p>
              <ul className="space-y-3 text-gray-700 mb-8">
                {[
                  'Premium Ribeye Steaks',
                  'Tenderloin (Filet Mignon)',
                  'New York Strip Steaks',
                  'Premium Ground Beef',
                  'Brisket and Chuck Roasts'
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="text-primary mr-2 h-5 w-5 mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Button 
                className="bg-primary hover:bg-primary/90 text-white"
                onClick={() => openContactModal('Beef')}
              >
                Inquire About Beef Products
              </Button>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Lamb Products */}
      <section id="lamb" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row-reverse items-center">
            <FadeInSection className="md:w-1/2 mb-8 md:mb-0 md:pl-12">
              <img 
                src="https://images.unsplash.com/photo-1608500218890-c4fbbddf8488?auto=format&fit=crop&q=80&w=1374" 
                alt="Premium Lamb Products" 
                className="rounded-lg shadow-md"
              />
            </FadeInSection>
            
            <FadeInSection delay={0.2} className="md:w-1/2">
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">Quality Lamb</h2>
              <div className="w-20 h-1 bg-primary mb-6"></div>
              <p className="text-gray-700 mb-4">
                Our lamb products come from animals raised in natural environments, where they graze on lush pastures. 
                This ensures meat that is tender, flavorful, and of the highest quality.
              </p>
              <p className="text-gray-700 mb-6">Our lamb product range includes:</p>
              <ul className="space-y-3 text-gray-700 mb-8">
                {[
                  'Lamb Racks and Chops',
                  'Leg of Lamb',
                  'Lamb Shoulder',
                  'Ground Lamb',
                  'Lamb Loin and Ribs'
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="text-primary mr-2 h-5 w-5 mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Button 
                className="bg-primary hover:bg-primary/90 text-white"
                onClick={() => openContactModal('Lamb')}
              >
                Inquire About Lamb Products
              </Button>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Poultry Products */}
      <section id="poultry" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <FadeInSection className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
              <img 
                src="https://images.unsplash.com/photo-1598103442097-8b74394b95c6?auto=format&fit=crop&q=80&w=1376" 
                alt="Premium Poultry Products" 
                className="rounded-lg shadow-md"
              />
            </FadeInSection>
            
            <FadeInSection delay={0.2} className="md:w-1/2">
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">Fresh Poultry</h2>
              <div className="w-20 h-1 bg-primary mb-6"></div>
              <p className="text-gray-700 mb-4">
                Our poultry products come from trusted farms that prioritize animal welfare and sustainable practices. 
                We offer chicken and turkey products of exceptional quality and freshness.
              </p>
              <p className="text-gray-700 mb-6">Our poultry product range includes:</p>
              <ul className="space-y-3 text-gray-700 mb-8">
                {[
                  'Whole Chickens',
                  'Chicken Breasts, Thighs, and Drumsticks',
                  'Turkey Breasts and Whole Turkeys',
                  'Boneless and Skinless Options',
                  'Premium Poultry Cuts for Export'
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="text-primary mr-2 h-5 w-5 mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Button 
                className="bg-primary hover:bg-primary/90 text-white"
                onClick={() => openContactModal('Poultry')}
              >
                Inquire About Poultry Products
              </Button>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Quality Standards */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
                Our Quality Standards
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-lg text-gray-700">
                All our products adhere to the highest quality standards and certifications, 
                ensuring safety, quality, and compliance with international regulations.
              </p>
            </div>
          </FadeInSection>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <FadeInSection delay={0.1}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Award className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">HACCP Certified</h3>
                  <p className="text-gray-600">Hazard Analysis Critical Control Point certification ensures food safety.</p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <ShieldCheck className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">ISO 22000</h3>
                  <p className="text-gray-600">International standard for food safety management systems.</p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.3}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">BRC Certified</h3>
                  <p className="text-gray-600">British Retail Consortium certification for food safety standards.</p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.4}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Animal Welfare</h3>
                  <p className="text-gray-600">Commitment to ethical treatment and animal welfare standards.</p>
                </CardContent>
              </Card>
            </FadeInSection>
          </div>
        </div>
      </section>
    </>
  );
};

export default Products;
