import { motion } from 'framer-motion';

const FadeInSection = ({ 
  children, 
  delay = 0, 
  direction = 'up', 
  className = '' 
}) => {
  
  let initialPosition = {};
  
  switch(direction) {
    case 'up':
      initialPosition = { y: 30 };
      break;
    case 'down':
      initialPosition = { y: -30 };
      break;
    case 'left':
      initialPosition = { x: 30 };
      break;
    case 'right':
      initialPosition = { x: -30 };
      break;
    case 'none':
      initialPosition = {};
      break;
  }
  
  return (
    <motion.div
      initial={{ 
        opacity: 0,
        ...initialPosition
      }}
      whileInView={{ 
        opacity: 1,
        x: 0,
        y: 0
      }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ 
        duration: 0.6, 
        delay, 
        ease: [0.22, 1, 0.36, 1] 
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

export default FadeInSection;