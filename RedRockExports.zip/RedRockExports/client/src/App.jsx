import { Route, Switch } from "wouter";
import { useState } from "react";

import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import WhatsAppButton from "@/components/layout/WhatsAppButton.jsx";
import FloatingContactButton from "@/components/layout/FloatingContactButton.jsx";
import ContactModal from "@/components/layout/ContactModal";

import Home from "@/pages/Home";
import About from "@/pages/About";
import Products from "@/pages/Products";
import Contact from "@/pages/Contact";
import NotFound from "@/pages/not-found";

function App() {
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [inquiryProduct, setInquiryProduct] = useState(null);

  const openContactModal = (product) => {
    setInquiryProduct(product || null);
    setIsContactModalOpen(true);
  };

  const closeContactModal = () => {
    setIsContactModalOpen(false);
    setInquiryProduct(null);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/about" component={About} />
          <Route path="/products">
            {() => <Products openContactModal={openContactModal} />}
          </Route>
          <Route path="/contact" component={Contact} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
      
      <FloatingContactButton onClick={() => openContactModal()} />
      <WhatsAppButton />
      <ContactModal 
        isOpen={isContactModalOpen} 
        onClose={closeContactModal}
        initialProduct={inquiryProduct}
      />
    </div>
  );
}

export default App;