import { Route, Switch } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";

import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import WhatsAppButton from "@/components/layout/WhatsAppButton";
import FloatingContactButton from "@/components/layout/FloatingContactButton";
import ContactModal from "@/components/layout/ContactModal";

import Home from "@/pages/Home";
import About from "@/pages/About";
import Products from "@/pages/Products";
import Contact from "@/pages/Contact";
import NotFound from "@/pages/not-found";

import { useState } from "react";

function App() {
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [inquiryProduct, setInquiryProduct] = useState<string | null>(null);

  const openContactModal = (product?: string) => {
    setInquiryProduct(product || null);
    setIsContactModalOpen(true);
  };

  const closeContactModal = () => {
    setIsContactModalOpen(false);
    setInquiryProduct(null);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/products">
              {() => <Products openContactModal={openContactModal} />}
            </Route>
            <Route path="/contact" component={Contact} />
            <Route component={NotFound} />
          </Switch>
        </main>
        <Footer />
      </div>
      
      <FloatingContactButton onClick={() => openContactModal()} />
      <WhatsAppButton />
      <ContactModal 
        isOpen={isContactModalOpen} 
        onClose={closeContactModal}
        initialProduct={inquiryProduct}
      />
      
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
