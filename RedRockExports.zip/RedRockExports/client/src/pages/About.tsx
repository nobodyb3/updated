import FadeInSection from '@/components/ui/motion/FadeInSection';
import { Card, CardContent } from '@/components/ui/card';
import { 
  ShieldCheck, 
  Recycle, 
  HeadphonesIcon,
  CheckCircle
} from 'lucide-react';

const About = () => {
  return (
    <>
      {/* About Hero Section */}
      <section className="relative py-20 bg-cover bg-center pt-32" style={{backgroundImage: `url('https://images.unsplash.com/photo-1555704574-a9aa8e82b3e4?auto=format&fit=crop&q=80&w=1470')`}}>
        <div className="absolute inset-0 bg-secondary bg-opacity-80"></div>
        <div className="container mx-auto px-4 relative z-10">
          <FadeInSection>
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-white font-display leading-tight mb-4">
                About RedRock Meat Exports
              </h1>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-xl text-white opacity-90">
                Learn about our journey, mission, and commitment to quality in the global meat export industry.
              </p>
            </div>
          </FadeInSection>
        </div>
      </section>
      
      {/* Our Story Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <FadeInSection className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
              <img 
                src="https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&q=80&w=1530" 
                alt="RedRock Meat Exports History" 
                className="rounded-lg shadow-md"
              />
            </FadeInSection>
            
            <FadeInSection delay={0.2} className="md:w-1/2">
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">Our Story</h2>
              <div className="w-20 h-1 bg-primary mb-6"></div>
              <p className="text-gray-700 mb-4">
                Founded in 2005, RedRock Meat Exports started with a simple mission: to provide the highest 
                quality meat products to global markets while maintaining ethical and sustainable practices.
              </p>
              <p className="text-gray-700 mb-4">
                Over the years, we have grown from a small local supplier to a global exporter, serving 
                clients in over 25 countries across 5 continents. Our success is built on our unwavering 
                commitment to quality, reliability, and customer satisfaction.
              </p>
              <p className="text-gray-700">
                Today, RedRock is recognized as a leading meat exporter, known for premium products that 
                meet the most stringent international standards and regulations.
              </p>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Mission & Values */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
                Our Mission & Values
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-lg text-gray-700">
                We are guided by core principles that ensure we deliver excellence in every aspect of our business.
              </p>
            </div>
          </FadeInSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FadeInSection delay={0.1}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <ShieldCheck className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Quality Assurance</h3>
                  <p className="text-gray-600">
                    We maintain rigorous quality control at every stage from sourcing to delivery, 
                    ensuring our products meet the highest standards.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Recycle className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Sustainability</h3>
                  <p className="text-gray-600">
                    We are committed to sustainable and ethical practices that minimize 
                    environmental impact and ensure animal welfare.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.3}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <HeadphonesIcon className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Customer Focus</h3>
                  <p className="text-gray-600">
                    We prioritize customer satisfaction by delivering exceptional products and personalized service.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Quality Assurance */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row-reverse items-center">
            <FadeInSection className="md:w-1/2 mb-8 md:mb-0 md:pl-12">
              <img 
                src="https://images.unsplash.com/photo-1560015534-1550645604bc?auto=format&fit=crop&q=80&w=1470" 
                alt="Quality Assurance Process" 
                className="rounded-lg shadow-md"
              />
            </FadeInSection>
            
            <FadeInSection delay={0.2} className="md:w-1/2">
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">Quality Assurance</h2>
              <div className="w-20 h-1 bg-primary mb-6"></div>
              <p className="text-gray-700 mb-4">
                At RedRock, quality is our top priority. Our comprehensive quality assurance system includes:
              </p>
              <ul className="space-y-3 text-gray-700 mb-6">
                {[
                  'Stringent selection of suppliers who adhere to our quality standards',
                  'Regular inspections and audits of production facilities',
                  'Comprehensive testing for safety and quality at multiple stages',
                  'Compliance with international food safety standards and regulations',
                  'Continuous training and development for our quality control team'
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="text-primary mr-2 h-5 w-5 mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-gray-700">
                Our dedication to quality has earned us numerous certifications and recognition from industry authorities worldwide.
              </p>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
                Our Leadership Team
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-lg text-gray-700">
                Meet the experienced professionals who lead RedRock Meat Exports to excellence.
              </p>
            </div>
          </FadeInSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <FadeInSection delay={0.1}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div className="h-64">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=1374" 
                    alt="CEO Robert Mitchell" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-1">Robert Mitchell</h3>
                  <p className="text-primary font-medium mb-3">Chief Executive Officer</p>
                  <p className="text-gray-600">
                    With over 25 years of experience in the meat industry, Robert leads our company with vision and expertise.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div className="h-64">
                  <img 
                    src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=1476" 
                    alt="COO Sarah Johnson" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-1">Sarah Johnson</h3>
                  <p className="text-primary font-medium mb-3">Chief Operations Officer</p>
                  <p className="text-gray-600">
                    Sarah oversees our global operations, ensuring efficiency and excellence in every process.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.3}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div className="h-64">
                  <img 
                    src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=1374" 
                    alt="Quality Director David Chen" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-1">David Chen</h3>
                  <p className="text-primary font-medium mb-3">Quality Assurance Director</p>
                  <p className="text-gray-600">
                    David leads our quality assurance team, maintaining our stringent standards across all products.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
