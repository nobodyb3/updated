import FadeInSection from '@/components/ui/motion/FadeInSection';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useState } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { MapPin, Phone, Mail, Clock, Globe, Ship, Headphones } from 'lucide-react';

const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().optional(),
  message: z.string().min(10, { message: "Message must be at least 10 characters" }),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

const Contact = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
    },
  });

  async function onSubmit(data: ContactFormValues) {
    setIsSubmitting(true);
    try {
      await apiRequest('POST', '/api/contact', data);
      toast({
        title: "Message sent",
        description: "Thank you for your message! We will contact you shortly.",
      });
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem sending your message. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <>
      {/* Contact Hero Section */}
      <section className="relative py-20 bg-cover bg-center pt-32" style={{backgroundImage: `url('https://images.unsplash.com/photo-1578574577315-3fbeb0cecdc2?auto=format&fit=crop&q=80&w=1372')`}}>
        <div className="absolute inset-0 bg-gray-900 bg-opacity-80"></div>
        <div className="container mx-auto px-4 relative z-10">
          <FadeInSection>
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-white font-display leading-tight mb-4">
                Contact Us
              </h1>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-xl text-white opacity-90">
                We'd love to hear from you. Reach out to discuss your requirements or learn more about our products.
              </p>
            </div>
          </FadeInSection>
        </div>
      </section>
      
      {/* Contact Information */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <FadeInSection>
              <div>
                <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">Get In Touch</h2>
                <div className="w-20 h-1 bg-primary mb-6"></div>
                <p className="text-gray-700 mb-8">
                  Whether you have a question about our products, pricing, or anything else, 
                  our team is ready to answer all your questions.
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="bg-primary bg-opacity-10 p-3 rounded-full mr-4">
                      <MapPin className="text-primary h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-1">Office Address</h3>
                      <p className="text-gray-600">
                        123 Business Avenue, Suite 500<br />
                        Industrial District, Karachi 75000<br />
                        Pakistan
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-primary bg-opacity-10 p-3 rounded-full mr-4">
                      <Phone className="text-primary h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-1">Phone Number</h3>
                      <p className="text-gray-600">+92 312 8528388</p>
                      <p className="text-gray-600">+92 21 1234567</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-primary bg-opacity-10 p-3 rounded-full mr-4">
                      <Mail className="text-primary h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-1">Email Address</h3>
                      <p className="text-gray-600">info@redrockmeatexports.com</p>
                      <p className="text-gray-600">sales@redrockmeatexports.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-primary bg-opacity-10 p-3 rounded-full mr-4">
                      <Clock className="text-primary h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-1">Business Hours</h3>
                      <p className="text-gray-600">Monday - Friday: 9:00 AM - 5:00 PM</p>
                      <p className="text-gray-600">Saturday: 9:00 AM - 1:00 PM</p>
                      <p className="text-gray-600">Sunday: Closed</p>
                    </div>
                  </div>
                </div>
              </div>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-2xl font-display font-bold text-gray-900 mb-6">Send Us a Message</h2>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone</FormLabel>
                            <FormControl>
                              <Input type="tel" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Message</FormLabel>
                            <FormControl>
                              <Textarea rows={4} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isSubmitting}>
                        {isSubmitting ? "Sending..." : "Send Message"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Map Section (Placeholder) */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="text-center max-w-3xl mx-auto mb-12">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
                Find Us
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-lg text-gray-700">
                Visit our headquarters to learn more about our operations and products.
              </p>
            </div>
          </FadeInSection>
          
          <FadeInSection delay={0.2}>
            <div className="h-96 rounded-lg overflow-hidden shadow-md border border-gray-200">
              {/* Map placeholder - This would be replaced with an actual map integration */}
              <div className="h-full w-full flex items-center justify-center bg-white">
                <div className="text-center p-6 max-w-md">
                  <div className="bg-primary bg-opacity-10 p-4 rounded-full inline-block mb-4">
                    <MapPin className="text-primary h-12 w-12" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">Our Headquarters</h3>
                  <p className="text-gray-700 mb-2">123 Business Avenue, Suite 500</p>
                  <p className="text-gray-700 mb-2">Industrial District, Karachi 75000</p>
                  <p className="text-gray-700 mb-4">Pakistan</p>
                  <p className="text-sm text-gray-500">An interactive map will be integrated here.</p>
                </div>
              </div>
            </div>
          </FadeInSection>
        </div>
      </section>
      
      {/* Global Presence */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
                Our Global Presence
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-lg text-gray-700">
                We export premium meat products to countries across the globe, 
                maintaining the highest standards of quality and service.
              </p>
            </div>
          </FadeInSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FadeInSection delay={0.1}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Globe className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">International Export</h3>
                  <p className="text-gray-600">
                    We export to over 25 countries across Asia, Europe, Middle East, and North America.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Ship className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Logistics Excellence</h3>
                  <p className="text-gray-600">
                    Our advanced logistics network ensures timely delivery while maintaining product quality.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.3}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Headphones className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Global Support</h3>
                  <p className="text-gray-600">
                    Our international team provides support in multiple languages to serve clients worldwide.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
