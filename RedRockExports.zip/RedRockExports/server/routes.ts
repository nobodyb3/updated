import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import nodemailer from "nodemailer";
import { insertContactSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      // Validate request body using Zod schema
      const contactData = insertContactSchema.parse(req.body);
      
      // Set up email transport
      // Note: In production, you would use a proper email service
      const transporter = nodemailer.createTransport({
        host: process.env.EMAIL_HOST || "smtp.example.com",
        port: parseInt(process.env.EMAIL_PORT || "587"),
        secure: process.env.EMAIL_SECURE === "true",
        auth: {
          user: process.env.EMAIL_USER || "user@example.com",
          pass: process.env.EMAIL_PASSWORD || "password",
        },
      });
      
      // Email content
      const mailOptions = {
        from: `"RedRock Meat Exports" <${process.env.EMAIL_FROM || "info@redrockmeatexports.com"}>`,
        to: process.env.EMAIL_TO || "info@redrockmeatexports.com",
        subject: "New Contact Form Submission",
        text: `
          Name: ${contactData.name}
          Email: ${contactData.email}
          Phone: ${contactData.phone || "Not provided"}
          
          Message:
          ${contactData.message}
        `,
        html: `
          <h2>New Contact Form Submission</h2>
          <p><strong>Name:</strong> ${contactData.name}</p>
          <p><strong>Email:</strong> ${contactData.email}</p>
          <p><strong>Phone:</strong> ${contactData.phone || "Not provided"}</p>
          <h3>Message:</h3>
          <p>${contactData.message.replace(/\n/g, "<br>")}</p>
        `,
      };
      
      // Store contact in database (if needed in the future)
      await storage.createContact({
        ...contactData,
        createdAt: new Date().toISOString(),
      });
      
      // Send email (wrapped in try/catch to handle email sending errors)
      try {
        await transporter.sendMail(mailOptions);
      } catch (emailError) {
        console.error("Error sending email:", emailError);
        // Still return success even if email fails, as we've stored the contact
      }
      
      res.status(200).json({ success: true, message: "Contact form submitted successfully" });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ 
          success: false, 
          message: "Validation error", 
          errors: validationError.message 
        });
      } else {
        console.error("Error processing contact form:", error);
        res.status(500).json({ 
          success: false, 
          message: "There was a problem submitting your message" 
        });
      }
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
