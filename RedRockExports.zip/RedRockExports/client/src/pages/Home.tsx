import { Link } from 'wouter';
import FadeInSection from '@/components/ui/motion/FadeInSection';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Award, Globe, Leaf, Star } from 'lucide-react';

const Home = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="relative h-screen bg-cover bg-center" style={{backgroundImage: `url('https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?auto=format&fit=crop&q=80&w=1470')`}}>
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        <div className="container mx-auto px-4 h-full flex items-center relative z-10">
          <div className="max-w-3xl">
            <FadeInSection>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white font-display leading-tight mb-4">
                Premium Quality Meat for Global Markets
              </h1>
            </FadeInSection>
            
            <FadeInSection delay={0.1}>
              <p className="text-xl text-white opacity-90 mb-8">
                RedRock Meat Exports delivers the finest beef, lamb, and poultry products with exceptional quality and service.
              </p>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link href="/products">
                  <Button size="lg" className="bg-primary hover:bg-primary/90 text-white">
                    Explore Products
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button size="lg" variant="outline" className="bg-white text-primary hover:bg-white/90">
                    Contact Us
                  </Button>
                </Link>
              </div>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Introduction Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
                Welcome to RedRock Meat Exports
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-lg text-gray-700">
                We are dedicated to providing premium quality meat products to our global clients. 
                Our commitment to excellence, sustainability, and ethical practices sets us apart in the industry.
              </p>
            </div>
          </FadeInSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FadeInSection delay={0.1}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Award className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Premium Quality</h3>
                  <p className="text-gray-600">
                    We source the finest meat products that meet stringent quality standards for global markets.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Globe className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Global Reach</h3>
                  <p className="text-gray-600">
                    We export to multiple countries, delivering top-quality meat products worldwide.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.3}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6 text-center">
                  <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Leaf className="text-primary h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Sustainable Practices</h3>
                  <p className="text-gray-600">
                    Our commitment to ethical and sustainable farming practices ensures responsible production.
                  </p>
                </CardContent>
              </Card>
            </FadeInSection>
          </div>
        </div>
      </section>
      
      {/* Product Showcase */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
                Our Premium Products
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
              <p className="text-lg text-gray-700">
                Discover our range of high-quality meat products sourced from the finest farms and processed to perfection.
              </p>
            </div>
          </FadeInSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FadeInSection delay={0.1}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div className="h-64">
                  <img 
                    src="https://images.unsplash.com/photo-1593604572577-1c6c44fa246c?auto=format&fit=crop&q=80&w=1376" 
                    alt="Premium Beef Products" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Premium Beef</h3>
                  <p className="text-gray-600 mb-4">
                    Our premium beef is sourced from grass-fed cattle, ensuring tender, flavorful cuts that meet the highest quality standards.
                  </p>
                  <Link href="/products#beef">
                    <span className="text-primary font-medium hover:underline flex items-center cursor-pointer">
                      Learn more <i className="ri-arrow-right-line ml-1"></i>
                    </span>
                  </Link>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div className="h-64">
                  <img 
                    src="https://images.unsplash.com/photo-1628268909376-e8c44bb5a4cf?auto=format&fit=crop&q=80&w=1470" 
                    alt="Premium Lamb Products" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Quality Lamb</h3>
                  <p className="text-gray-600 mb-4">
                    Our lamb products come from free-range animals raised in natural environments, delivering exceptional taste and tenderness.
                  </p>
                  <Link href="/products#lamb">
                    <span className="text-primary font-medium hover:underline flex items-center cursor-pointer">
                      Learn more <i className="ri-arrow-right-line ml-1"></i>
                    </span>
                  </Link>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.3}>
              <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <div className="h-64">
                  <img 
                    src="https://images.unsplash.com/photo-1604503468506-a8da13d82791?auto=format&fit=crop&q=80&w=1374" 
                    alt="Premium Poultry Products" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Fresh Poultry</h3>
                  <p className="text-gray-600 mb-4">
                    Our poultry products are sourced from trusted farms that prioritize animal welfare, delivering premium quality meat.
                  </p>
                  <Link href="/products#poultry">
                    <span className="text-primary font-medium hover:underline flex items-center cursor-pointer">
                      Learn more <i className="ri-arrow-right-line ml-1"></i>
                    </span>
                  </Link>
                </CardContent>
              </Card>
            </FadeInSection>
          </div>
          
          <FadeInSection delay={0.4}>
            <div className="text-center mt-12">
              <Link href="/products">
                <Button className="bg-primary hover:bg-primary/90 text-white">
                  View All Products
                </Button>
              </Link>
            </div>
          </FadeInSection>
        </div>
      </section>
      
      {/* Testimonial Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <FadeInSection>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-display font-bold text-gray-900 mb-4">
                What Our Clients Say
              </h2>
              <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            </div>
          </FadeInSection>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <FadeInSection delay={0.1}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="inline h-5 w-5 fill-current" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-700 mb-6 italic">
                    "RedRock Meat Exports has been our trusted supplier for over 5 years. 
                    Their consistent quality and reliability have made them an invaluable partner for our business."
                  </p>
                  <div className="flex items-center">
                    <div>
                      <h4 className="font-semibold">John Decker</h4>
                      <p className="text-sm text-gray-500">Global Foods Inc.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </FadeInSection>
            
            <FadeInSection delay={0.2}>
              <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="inline h-5 w-5 fill-current" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-700 mb-6 italic">
                    "The quality of meat products from RedRock is exceptional. 
                    Their commitment to sustainability and ethical practices aligns perfectly with our company values."
                  </p>
                  <div className="flex items-center">
                    <div>
                      <h4 className="font-semibold">Sarah Kim</h4>
                      <p className="text-sm text-gray-500">Premium Imports Ltd.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </FadeInSection>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
