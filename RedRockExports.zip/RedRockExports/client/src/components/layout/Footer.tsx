import { Link } from 'wouter';
import { 
  FacebookIcon, 
  TwitterIcon, 
  LinkedinIcon, 
  InstagramIcon, 
  MapPin, 
  Phone, 
  Mail 
} from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div>
            <h3 className="text-2xl font-display font-bold mb-4">RedRock Meat Exports</h3>
            <p className="mb-4 text-gray-300">Providing premium quality meat products to global markets with the highest standards of excellence.</p>
            <div className="flex space-x-4">
              <Link href="#">
                <div 
                  className="text-white hover:text-primary transition-colors duration-300 cursor-pointer"
                  aria-label="Facebook"
                >
                  <FacebookIcon size={20} />
                </div>
              </Link>
              <Link href="#">
                <div 
                  className="text-white hover:text-primary transition-colors duration-300 cursor-pointer"
                  aria-label="Twitter"
                >
                  <TwitterIcon size={20} />
                </div>
              </Link>
              <Link href="#">
                <div 
                  className="text-white hover:text-primary transition-colors duration-300 cursor-pointer"
                  aria-label="LinkedIn"
                >
                  <LinkedinIcon size={20} />
                </div>
              </Link>
              <Link href="#">
                <div 
                  className="text-white hover:text-primary transition-colors duration-300 cursor-pointer"
                  aria-label="Instagram"
                >
                  <InstagramIcon size={20} />
                </div>
              </Link>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <div className="text-gray-300 hover:text-primary transition-colors duration-300 cursor-pointer">Home</div>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <div className="text-gray-300 hover:text-primary transition-colors duration-300 cursor-pointer">About Us</div>
                </Link>
              </li>
              <li>
                <Link href="/products">
                  <div className="text-gray-300 hover:text-primary transition-colors duration-300 cursor-pointer">Products</div>
                </Link>
              </li>
              <li>
                <Link href="/products#beef">
                  <div className="text-gray-300 hover:text-primary transition-colors duration-300 cursor-pointer">Beef Products</div>
                </Link>
              </li>
              <li>
                <Link href="/products#lamb">
                  <div className="text-gray-300 hover:text-primary transition-colors duration-300 cursor-pointer">Lamb Products</div>
                </Link>
              </li>
              <li>
                <Link href="/products#poultry">
                  <div className="text-gray-300 hover:text-primary transition-colors duration-300 cursor-pointer">Poultry Products</div>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <div className="text-gray-300 hover:text-primary transition-colors duration-300 cursor-pointer">Contact Us</div>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Contact Information</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="text-primary mr-3 mt-1 shrink-0" size={20} />
                <span>123 Business Avenue, Suite 500<br />Industrial District, Karachi 75000<br />Pakistan</span>
              </li>
              <li className="flex items-center">
                <Phone className="text-primary mr-3 shrink-0" size={20} />
                <span>+92 312 8528388</span>
              </li>
              <li className="flex items-center">
                <Mail className="text-primary mr-3 shrink-0" size={20} />
                <span>info@redrockmeatexports.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 mb-4 md:mb-0">&copy; {new Date().getFullYear()} RedRock Meat Exports. All rights reserved.</p>
            <div className="flex flex-wrap gap-6">
              <Link href="#">
                <div className="text-gray-400 hover:text-primary transition-colors duration-300 cursor-pointer">Privacy Policy</div>
              </Link>
              <Link href="#">
                <div className="text-gray-400 hover:text-primary transition-colors duration-300 cursor-pointer">Terms of Service</div>
              </Link>
              <Link href="#">
                <div className="text-gray-400 hover:text-primary transition-colors duration-300 cursor-pointer">Sitemap</div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
