import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on navigation
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-gray-900 shadow-md py-3' : 'bg-gray-900/95 py-4'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <Link href="/">
            <div className="flex items-center space-x-2 cursor-pointer">
              <span className="text-primary font-bold text-3xl font-display">RedRock</span>
              <span className="text-white font-semibold text-lg">Meat Exports</span>
            </div>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            <NavLink href="/" isActive={location === '/'}>Home</NavLink>
            <NavLink href="/about" isActive={location === '/about'}>About Us</NavLink>
            <NavLink href="/products" isActive={location === '/products'}>Products</NavLink>
            <NavLink href="/contact" isActive={location === '/contact'}>Contact</NavLink>
          </div>
          
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)} 
            className="md:hidden text-white focus:outline-none"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 animate-fade-in">
            <Link href="/">
              <div className="block py-2 text-white hover:text-primary font-medium transition-colors duration-300">Home</div>
            </Link>
            <Link href="/about">
              <div className="block py-2 text-white hover:text-primary font-medium transition-colors duration-300">About Us</div>
            </Link>
            <Link href="/products">
              <div className="block py-2 text-white hover:text-primary font-medium transition-colors duration-300">Products</div>
            </Link>
            <Link href="/contact">
              <div className="block py-2 text-white hover:text-primary font-medium transition-colors duration-300">Contact</div>
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
};

const NavLink = ({ href, isActive, children }) => {
  return (
    <Link href={href}>
      <div className={`nav-link text-white hover:text-primary font-medium transition-colors duration-300 relative
        ${isActive ? 'active text-primary' : ''}
        after:content-[''] after:absolute after:h-0.5 after:w-0 after:left-0 after:bottom-[-2px] after:bg-primary 
        after:transition-all after:duration-300 
        ${isActive ? 'after:w-full' : 'hover:after:w-full'}
      `}>
        {children}
      </div>
    </Link>
  );
};

export default Header;